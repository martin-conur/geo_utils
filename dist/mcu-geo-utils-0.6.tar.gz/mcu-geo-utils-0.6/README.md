# mcu_geo_utils
Personal library designed to easily perform geo-related tasks, such as OSM data extraction and other demographic data analysis.
